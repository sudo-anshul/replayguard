# ReplayGuard regression case

This archive captures a bounded real AWS SQS/Lambda failure comparison.
`evidence.json` reports the observed run; `assertions.json` is independently
recomputed at export. PASSED requires the exact original SQS messages to retry,
a durable receipt before each injected failure, eventual success, duplicate
vulnerable receipts, a single repaired receipt, and stable queue drainage.
INCOMPLETE means required observations are missing; UNRESOLVED means observations
contradict the case. Neither state is a successful AWS validation.

Verify the unmodified archive locally (no AWS credentials needed):

```sh
python3 scripts/verify_case.py evidence.json --case case.json --json
```

Check every file's integrity with `shasum -a 256 -c SHA256SUMS` (macOS) or
`sha256sum -c SHA256SUMS` (Linux). Checksums detect changed bytes; these exports
are not cryptographically signed by AWS and do not independently prove origin.

Deploy the included source, then replay against a short-lived AWS stack. Prerequisites:
Python 3.10+, AWS CLI v2 on PATH, and an authenticated AWS profile authorized to
create the scoped CloudFormation/IAM/Lambda/SQS/DynamoDB/CloudWatch lab resources.
Deployment creates billable AWS resources; credits are not a spending cap.

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python scripts/deploy.py --profile YOUR_PROFILE --region YOUR_REGION --stack replayguard-lab --hours 1
python scripts/run_case.py --profile YOUR_PROFILE --region YOUR_REGION --stack replayguard-lab --case case.json --output new-evidence.json
python scripts/verify_case.py new-evidence.json --case case.json
python scripts/export_case.py --case case.json --evidence new-evidence.json --output new-regression.zip
python scripts/destroy.py --profile YOUR_PROFILE --region YOUR_REGION --stack replayguard-lab
```

If a matching active stack already exists, skip deployment. The runner only
submits to an existing stack and refuses expired deployments or nonempty queues.
Deployment source is included under src/, infra/ and scripts/ and its SHA-256
fingerprints are captured in evidence.json. Each replay gets a new run UUID and
sends one message per mode per order (maximum six), with a maximum 180-second
observation window, a 300-call collector budget and five-page per-read limit.
Delete the lab when done; expiry stops fulfillment but does not delete resources.

Fault: the worker invokes the independent simulated fulfillment provider,
then throws on SQS receiveCount 1 after the provider has durably written a receipt.
SQS redelivers the same message. Vulnerable mode accepts another receipt; repaired
mode uses receiver-side atomic idempotency and reuses the original receipt.
No real payment, shipment, email or customer order is generated. The repair
models a receiver that atomically owns the effect and idempotency decision.

Artifact source fingerprints and sanitized AWS API errors (if any) are retained
inside evidence.json. CloudWatch logs can arrive late; missing evidence stays
incomplete. SQS queue counts are approximate. This bounded demonstration is not
a general exactly-once guarantee for distributed systems or external APIs.
