# ReplayGuard: execute a regression locally

Requirements: Python 3.11+ on macOS or Linux (POSIX delivery timers).
Windows is not supported by this runner. No pip install, third-party dependencies, AWS
credentials, network connection or paid service is needed. From this extracted
folder, run:

```sh
python3 -I -S scripts/run_local.py --output local-results.json
```

This command imports and executes **the worker and fulfillment receiver source
in this archive**. A local Lambda transport calls the real receiver; a memory
ledger implements its conditional-write API. The observer reads a separate
ledger snapshot rather than trusting the handler's return value. Python audit
hooks block network/process attempts; clean extraction validation also used a
macOS OS-level network-denial profile. See the recorded validation outside this
archive for the exact platform and command.

The fixed suite includes both no-fault controls, a crash/retry comparison,
different message IDs for the same business order, withheld observations, and
an explicitly unsupported external-side-effect model. Suite success means the
observed business verdicts match the declared case expectations. It DOES NOT
mean the intentionally vulnerable handler is safe.

Check one handler's business verdict (the process exit code is its result):

```sh
python3 -I -S scripts/run_local.py --case crash-after-fulfillment --mode vulnerable
# expected violation: exit 1
python3 -I -S scripts/run_local.py --case crash-after-fulfillment --mode repaired
# expected pass: exit 0
```

Exit codes: 0 pass, 1 business violation, 2 incomplete/missing observation,
3 unresolved/unsupported. An immediately throwing handler cannot satisfy a
successful-fulfillment control. Declared schedules are bounded local calls;
they do not simulate AWS visibility timing, deployment, delivery guarantees,
concurrency, throttling or network failure. The receipt is the simulated effect.
An arbitrary external side effect without an atomic receiver contract remains
unsupported. The Python guard is not a sandbox for hostile native code.

## Different action: verify archived AWS observations

```sh
python3 -I -S scripts/verify_case.py evidence/latest.json --case cases/crash-after-fulfillment.json
```

This checks the consistency of saved AWS JSON. It does not execute the handlers
or prove that a changed implementation passed on AWS. The genuine historical
AWS run and its matching source are preserved byte-for-byte inside
`historical/aws-regression-case.zip`. Do not rewrite its hashes or label new
local results as AWS evidence. Cloud work is currently stopped: cumulative
spending headroom is unresolved, and this iteration allows $0 chargeable work.
Both original project stacks have saved DELETE_COMPLETE records; this local
command neither checks nor recreates them.

`SHA256SUMS` records every other package file. On macOS use
`shasum -a 256 -c SHA256SUMS`; on Linux use `sha256sum -c SHA256SUMS`.
Hashes establish byte consistency, not AWS-signed authenticity. The fixed plan
is at `docs/iteration-01/plan.json`; local results fingerprint executed code and
case inputs. No stored result is used as a current pass/fail oracle.
