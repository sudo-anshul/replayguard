# ReplayGuard AWS key-scope regression

This is a versioned, bounded AWS observation. Check `assertions.json` for the
experiment's completeness, each candidate's business result, and cleanup state.
Two intentionally faulty candidates should violate the valid-order invariant.
An experiment pass does not turn their business results into passes.

Verify without AWS credentials or third-party packages:

```sh
python3 scripts/verify_key_case.py evidence.json --case case.json --json
shasum -a 256 -c SHA256SUMS
```

Checksums identify changed bytes; they are not AWS signatures or trusted origin
attestation. The independent observer queries the DynamoDB receipt ledger. A
receipt is the entire simulated effect, not a real payment or shipment.

To run again, use Python 3.10+, AWS CLI v2 and a trusted AWS profile authorized
for the small private CloudFormation/Lambda/SQS/DynamoDB/CloudWatch lab. First
check current gross spending and allow for billing lag; credits are not a cap.
This creates billable resources. There is no public execution endpoint.

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python scripts/deploy.py --experiment key-scope --hours 1 --stack replayguard-key-replay --profile YOUR_PROFILE --region us-east-1
python scripts/run_key_case.py --stack replayguard-key-replay --profile YOUR_PROFILE --region us-east-1 --case case.json --output new-evidence.json
python scripts/verify_key_case.py new-evidence.json --case case.json
python scripts/export_key_case.py --case case.json --evidence new-evidence.json --output new-regression.zip
```

The runner ALWAYS attempts to disable and delete the exact verified stack tagged
Project=ReplayGuard and Experiment=key-scope, including if observation/export
fails. It does not delete the separate Amplify host. Check the cleanup record;
unconfirmed deletion remains an unresolved operational task. If deployment
succeeded but the runner could not start, clean up the named lab explicitly:

```sh
python scripts/destroy.py --stack replayguard-key-replay --profile YOUR_PROFILE --region us-east-1
```

Three original A messages are sent, one per fixed key choice. Only after every
A receipt and correlated post-commit failure has been observed are three B
messages sent. A and B share a SKU. The provider conditionally writes a receipt,
then deliberately fails its response after a NEW first-receive commit. The
worker fails and standard SQS redelivers it. Recognized payload conflicts are
acknowledged as terminal business rejections, not counted as fulfillment.

No key must expose at least two receipts per order, SKU key must expose one A
receipt and an evidenced rejected B, and order key must retain one per order.
Actual extra SQS deliveries stay in the evidence. There is no total-order,
exactly-two-deliveries or universal exactly-once claim. This is a response and
function failure, not an OS process kill. Missing first-receive/fault evidence
prevents an experiment pass.

Bounds: six original sends, 420-second collection, 400 collector API calls,
five pages per read, mapping concurrency two, one-hour processing expiry.
Cleanup has a separate bounded verification budget. Expiry and TTL do not
delete the lab and are not dollar-exact billing limits. Source fingerprints
cover the packaged sources and match the CloudFormation inline worker/provider
template inspected before dispatch. They are not a dependency attestation.
